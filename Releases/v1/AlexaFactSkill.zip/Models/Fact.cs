﻿namespace $safeprojectname$.Models
{
    public class Fact
    {
        public string Intent { get; set; }
        public string[] Texts { get; set; }
    }
}